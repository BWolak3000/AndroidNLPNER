package edu.embedednlpner;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        Intent int_main = getIntent();              //pobranie intentu z manin activity
        String text = int_main.getStringExtra("data");     //pobranie extra wartosci z intentu
        TextView result = (TextView) findViewById(R.id.result);
        result.setText(text);
    }

}