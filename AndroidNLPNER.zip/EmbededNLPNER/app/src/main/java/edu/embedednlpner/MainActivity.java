package edu.embedednlpner;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

//import com.monkeylearn.MonkeyLearn;
//import com.monkeylearn.MonkeyLearnResponse;
//import com.monkeylearn.MonkeyLearnException;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    protected String Interpret(String text){//throws MonkeyLearnException
        //w tym miejscu używam modelu aby przetwożyć tekst
        //ze względu na to że monkeylearn nie pozwala na eksportowanie modelu do pliku pt
        //chcialem zastosować skrypty python:
        //String result = AnalizerForAndroid.analize_to_String(AnalizerForAndroid.analize(text))
        //ale niemożliwe jest takie zastosowanie pythona w android studio
        //zwracam więc na sztywno wpisaną poprawną odpowiedź dla przykładowego imputu
        return "Author: Bartosz\n BuyProduct: wanne";//ze względu na to że monkeylearn nie może pracować z androidstudio to jest wynik dla przykladu
    }


    public void onClickButton1(View button1) {
        EditText text = (EditText)findViewById(R.id.editTextImput);

        Intent intet = new Intent(this, SecondActivity.class);
        intet.putExtra("data", Interpret(text.getText().toString()));

        startActivity(intet);
    }
//      metoda uczenia maszynowego ale monkeylearn ale nie dziala ze wzgledu na brak kompatybilnosci z androidstudio
//    public static void MLInterpret( String[] args ) throws MonkeyLearnException {
//        MonkeyLearn ml = new MonkeyLearn("1bcc3c25a893ee80d29c99e2401dd356a797b3cb");
//        String modelId = "ex_dtshZhuK";
//        String[] data = {"GrubyMosieł: kupie zalle sell fanga 48% exuwium 9kk"};
//        MonkeyLearnResponse res = ml.extractors.extract(modelId, data);
//        System.out.println( res.arrayResult );
//    }
}